# MeshLens — 18 already-measured benchmark examples

These are 256x256 derivatives of the MVTec AD Grid test images used in the app.
They are replay examples, NOT new independent validation data.

1. Open MeshLens and use Upload or drop an image.
2. Choose images/good-000.png: normal; expected Within learned range.
3. Choose images/bent-000.png: known defect; expected Review recommended.
4. Choose images/bent-001.png: known defect; expected Within learned range.
   Step 4 demonstrates a missed defect. A low score does not establish defect-free material.
5. Compare Original, Reconstruction, and Error map; then read the known label
   in manifest.json. Uploading a local file does not automatically know its label.

The manifest provides all labels, source paths, frozen expected scores and SHA256
checksums. Small numeric runtime differences are possible. The fixed limit is
0.02402208368407517; only strictly larger scores recommend review.
The error map is relative to each image, not a probability or a validated boundary.

For genuinely new data, capture similar mesh under controlled focus, lighting,
viewpoint and scale. Label it independently before measuring misses and false alarms.
All images in the complete Grid benchmark already belong to this experiment.

Official dataset: https://www.mvtec.com/research-teaching/datasets/mvtec-ad
Dataset copyright: MVTec Software GmbH and original authors.
License: CC BY-NC-SA 4.0 (noncommercial).
https://creativecommons.org/licenses/by-nc-sa/4.0/
Original data license and readme are included. Dataset terms also apply to derivatives.
Project: https://github.com/kumarwaibhav/MeshLens

# MeshLens: 18 benchmark replay examples

These are canonical 256 px derivatives of already-evaluated MVTec AD Grid test images.
They are not independent field validation data. Uploading them does not retrain the model.

The active detector is meshlens-inspect-7665cb57f023. Its frozen score is not a probability.
Review only when score > 1.01049636; equality is within range.
Try good-000.png, bent-000.png, then glue-008.png: glue-008 is an actual missed defect.
Low score does not establish defect-free material. Read manifest.json for all known labels.
Reconstruction is a historical autoencoder illustration, separate from the active detector score.

All 342 Grid benchmark images already belong to this experiment. Capture and independently label
new target-line images for independent validation; transformed copies are not new parts.
Official dataset: https://www.mvtec.com/research-teaching/datasets/mvtec-ad
Data copyright: MVTec Software GmbH and original authors.
License: CC BY-NC-SA 4.0; noncommercial. Terms apply to derivatives.
https://creativecommons.org/licenses/by-nc-sa/4.0/
